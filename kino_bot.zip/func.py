from aiogram.types import Message
from aiogram.fsm.context import FSMContext
import states
import data
import keyboards
import main

async def start_xabari(message:Message):
    matn = (
        f"""👋 Assalomu alaykum {message.from_user.full_name} botimizga xush kelibsiz.

✍🏻 Kino kodini yuboring."""
    )
    await message.answer(text=matn)

async def kino_kodi(message:Message):
    if message.text.isdigit():
        print(data.kino_data.get(message.text), message.text)
        if data.kino_data.get(message.text)!=None:
            link = data.kino_data.get(message.text).get('kino_link')
            kino_matni = data.kino_data.get(message.text).get('caption')
            await message.answer_video(video=link, caption=kino_matni,reply_markup=keyboards.inline_tugma)
        else: await message.answer(text='kino topilmadi')

async def kino_qosh(message:Message, state:FSMContext):
    if str(message.from_user.id)==main.admin_id:
        await message.answer(text='kino kodini kiriting')
        await state.set_state(states.kino_olish.kod)
    else:
        await message.answer(text='siz admin emassiz bu bo\'lim faqat adminlar uchun')
        await state.clear()
async def kino_link(message:Message, state:FSMContext):
    await state.update_data(kod = message.text)
    data.kino_data[message.text] = {}
    await message.answer(text='kino linkini yuboring: ')
    await state.set_state(states.kino_olish.link)

async def kino_caption(message:Message, state:FSMContext):
    await state.update_data(link = message.text)
    await message.answer(text='kino xaqida matn: ')
    await state.set_state(states.kino_olish.matn)

async def kino_gtv(message:Message, state:FSMContext):
    await state.update_data(matn=message.text)
    data1 = await state.get_data()
    data.kino_data[data1.get('kod')] = {'kino_link':data1.get('link'), 'caption': data1.get('matn')}
    await message.answer(text='kino qabul qilindi')
    await state.clear()
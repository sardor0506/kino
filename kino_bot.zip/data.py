kino_data = {
    '1': {'kino_link':'https://t.me/kino_topish_bot_kodli/2','caption':'kino haqida'}
}
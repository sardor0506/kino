from aiogram.types import CallbackQuery

async def delet_kino(callback_data:CallbackQuery):
    await callback_data.answer(text='kino yoqmadi')
    await callback_data.message.delete()
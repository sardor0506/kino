from aiogram.fsm.state import State, StatesGroup

class kino_olish(StatesGroup):
    kod = State()
    link = State()
    matn = State()
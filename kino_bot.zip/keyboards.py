from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

inline_tugma = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='ulashish', url='https://t.me/share/url?url=t.me/kino_kodli_media_robot')
        ],
        [
            InlineKeyboardButton(text='delet ❌', callback_data='yoq'),
            InlineKeyboardButton(text='save ✅', callback_data='ha')
        ]
    ]
)
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, BotCommand
from aiogram.filters import CommandStart, Command
from asyncio import run
import func
import states
import keyboards
import callback_func

admin_id = '7223024122'
TOKEN = '7421644501:AAFB5w89-fdPVINBvgIF0IGP0CrGWW7ZXXc'
dp = Dispatcher()

async def start_bot_answer(bot: Bot):
    await bot.send_message(chat_id=admin_id, text='Bot ishga tushirildi')

async def stop_bot_answer(bot: Bot):
    await bot.send_message(chat_id=admin_id, text='Bot to\'xtatildi')

async def start():
    dp.startup.register(start_bot_answer)
    dp.message.register(func.start_xabari, CommandStart())
    dp.message.register(func.kino_qosh, Command('admin'))
    dp.message.register(func.kino_link, states.kino_olish.kod)
    dp.message.register(func.kino_caption, states.kino_olish.link)
    dp.message.register(func.kino_gtv, states.kino_olish.matn)
    dp.message.register(func.kino_kodi)
    dp.callback_query.register(callback_func.delet_kino, F.data=='yoq')
    dp.shutdown.register(stop_bot_answer)

    bot = Bot(TOKEN)
    await bot.set_my_commands([
        BotCommand(command='/start', description='Botni ishga tushirish'),
        BotCommand(command='/help', description='Yordam')
    ])
    
    await dp.start_polling(bot)

if __name__ == '__main__':
    run(start())
